require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({
  host:     process.env.DB_HOST     || 'localhost',
  port:     parseInt(process.env.DB_PORT) || 5432,
  database: process.env.DB_NAME     || 'elib',
  user:     process.env.DB_USER     || 'postgres',
  password: process.env.DB_PASSWORD || '',
});

// Verify connection on startup
pool.connect((err, client, release) => {
  if (err) {
    console.error('❌  Cannot connect to PostgreSQL:', err.message);
    console.error('   Check your .env settings (DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD)');
    process.exit(1);
  }
  release();
  console.log('✅  PostgreSQL connected →', process.env.DB_NAME || 'elib');
});

module.exports = pool;
